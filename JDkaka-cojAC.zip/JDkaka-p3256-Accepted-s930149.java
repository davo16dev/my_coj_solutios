import java.util.Scanner;
public class COJComputmat {

    
    public static void main(String[] args) {
        Scanner Leer=new Scanner(System.in);
        
        long N=Leer.nextInt();
        long P=N*N+1;
        
        
        
        
        
        
  
        System.out.println(P);
    }
    
}
