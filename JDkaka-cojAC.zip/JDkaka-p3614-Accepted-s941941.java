import java.util.Scanner;
/**
 *
 * @author bhroque
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc  =  new Scanner (System.in);
        int cant = sc.nextInt(), a;
        for (int i = 0; i < cant; i++) {
            a = sc.nextInt();
            if (a==0)
                System.out.println("zero");
            else if (a==1)
                System.out.println("one");
            else if (a==2)
                System.out.println("two");
            else if (a==3)
                System.out.println("three");
            else if (a==4)
                System.out.println("four");
            else if (a==5)
                System.out.println("five");
            else if (a==6)
                System.out.println("six");
            else if (a==7)
                System.out.println("seven");
            else if (a==8)
                System.out.println("eight");
            else if (a==9)
                System.out.println("nine");
            else if (a==10)
                System.out.println("ten");
            else if (a==11)
                System.out.println("eleven");
            else if (a==12)
                System.out.println("twelve");
            else if (a==13)
                System.out.println("thirteen");
            else if (a==14)
                System.out.println("fourteen");
            else if (a==15)
                System.out.println("fifteen");
            else if (a==16)
                System.out.println("sixteen");
            else if (a==17)
                System.out.println("seventeen");
            else if (a==18)
                System.out.println("eighteen");
            else if (a==19)
                System.out.println("nineteen");
            else if (a==20)
                System.out.println("twenty");
            else if (a==21)
                System.out.println("twenty-one");
            else if (a==22)
                System.out.println("twenty-two");
            else if (a==23)
                System.out.println("twenty-three");
            else if (a==24)
                System.out.println("twenty-four");
            else if (a==25)
                System.out.println("twenty-five");
            else if (a==26)
                System.out.println("twenty-six");
            else if (a==27)
                System.out.println("twenty-seven");
            else if (a==28)
                System.out.println("twenty-eight");
            else if (a==29)
                System.out.println("twenty-nine");
            else if (a==30)
                System.out.println("thirty");
            else if (a==31)
                System.out.println("thirty-one");
            else if (a==32)
                System.out.println("thirty-two");
            else if (a==33)
                System.out.println("thirty-three");
            else if (a==34)
                System.out.println("thirty-four");
            else if (a==35)
                System.out.println("thirty-five");
            else if (a==36)
                System.out.println("thirty-six");
            else if (a==37)
                System.out.println("thirty-seven");
            else if (a==38)
                System.out.println("thirty-eight");
            else if (a==39)
                System.out.println("thirty-nine");
            else if (a==40)
                System.out.println("forty");
            else if (a==41)
                System.out.println("forty-one");
            else if (a==42)
                System.out.println("forty-two");
            else if (a==43)
                System.out.println("forty-three");
            else if (a==44)
                System.out.println("forty-four");
            else if (a==45)
                System.out.println("forty-five");
            else if (a==46)
                System.out.println("forty-six");
            else if (a==47)
                System.out.println("forty-seven");
            else if (a==48)
                System.out.println("forty-eight");
            else if (a==49)
                System.out.println("forty-nine");
            else if (a==50)
                System.out.println("fifty");
            else if (a==51)
                System.out.println("fifty-one");
            else if (a==52)
                System.out.println("fifty-two");
            else if (a==53)
                System.out.println("fifty-three");
            else if (a==54)
                System.out.println("fifty-four");
            else if (a==55)
                System.out.println("fifty-five");
            else if (a==56)
                System.out.println("fifty-six");
            else if (a==57)
                System.out.println("fifty-seven");
            else if (a==58)
                System.out.println("fifty-eight");
            else if (a==59)
                System.out.println("fifty-nine");
            else if (a==60)
                System.out.println("sixty");
            else if (a==61)
                System.out.println("sixty-one");
            else if (a==62)
                System.out.println("sixty-two");
            else if (a==63)
                System.out.println("sixty-three");
            else if (a==64)
                System.out.println("sixty-four");
            else if (a==65)
                System.out.println("sixty-five");
            else if (a==66)
                System.out.println("sixty-six");
            else if (a==67)
                System.out.println("sixty-seven");
            else if (a==68)
                System.out.println("sixty-eight");
            else if (a==69)
                System.out.println("sixty-nine");
            else if (a==70)
                System.out.println("seventy");
            else if (a==71)
                System.out.println("seventy-one");
            else if (a==72)
                System.out.println("seventy-two");
            else if (a==73)
                System.out.println("seventy-three");
            else if (a==74)
                System.out.println("seventy-four");
            else if (a==75)
                System.out.println("seventy-five");
            else if (a==76)
                System.out.println("seventy-six");
            else if (a==77)
                System.out.println("seventy-seven");
            else if (a==78)
                System.out.println("seventy-eight");
            else if (a==79)
                System.out.println("seventy-nine");
            else if (a==80)
                System.out.println("eighty");
            else if (a==81)
                System.out.println("eighty-one");
            else if (a==82)
                System.out.println("eighty-two");
            else if (a==83)
                System.out.println("eighty-three");
            else if (a==84)
                System.out.println("eighty-four");
            else if (a==85)
                System.out.println("eighty-five");
            else if (a==86)
                System.out.println("eighty-six");
            else if (a==87)
                System.out.println("eighty-seven");
            else if (a==88)
                System.out.println("eighty-eight");
            else if (a==89)
                System.out.println("eighty-nine");
            else if (a==90)
                System.out.println("ninety");
            else if (a==91)
                System.out.println("ninety-one");
            else if (a==92)
                System.out.println("ninety-two");
            else if (a==93)
                System.out.println("ninety-three");
            else if (a==94)
                System.out.println("ninety-four");
            else if (a==95)
                System.out.println("ninety-five");
            else if (a==96)
                System.out.println("ninety-six");
            else if (a==97)
                System.out.println("ninety-seven");
            else if (a==98)
                System.out.println("ninety-eight");
            else if (a==99)
                System.out.println("ninety-nine");
        }
    }
}