import java.util.Scanner;
/**
 *
 * @author docencia
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a,b;
        Scanner sc  = new Scanner (System.in);
        a = sc.nextInt();
        for (int i = 0; i < a; i++) {
            b= sc.nextInt();
            if(b==1)
                System.out.println("one");
            if(b==2)
                System.out.println("two");
            if(b==3)
                System.out.println("three");
            if(b==4)
                System.out.println("four");
            if(b==5)
                System.out.println("five");
            if(b==6)
                System.out.println("six");
            if(b==7)
                System.out.println("seven");
            if(b==8)
                System.out.println("eight");
            if(b==9)
                System.out.println("nine");
            if(b==10)
                System.out.println("ten");
            if(b==11)
                System.out.println("eleven");
            if(b==12)
                System.out.println("twelve");
        }
        
    }}