import java.util.Scanner;

/**
 *
 * @author Charlie-PC
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    
    Scanner Leer=new Scanner(System.in);
    
    long muj=Leer.nextLong();
      muj=(long) ((muj*0.35)/10);
   
        System.out.println(muj);
    
    
    
    }
    
}
