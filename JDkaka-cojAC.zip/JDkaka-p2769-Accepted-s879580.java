import java.util.Scanner;
public class DETERMINE {

    
    public static void main(String[] args) {
        Scanner Leer=new Scanner(System.in);
        long cas=Leer.nextLong();
        
        for(long i=1 ; i<=cas ; i++){
            System.out.println(i+": I am participating in the Engineer's day.");
        }
                }
    
}