import java.util.Scanner;


public class Main {
 
    public static void main(String[] args) {
      Scanner Leer =new Scanner(System.in); 
int R1=Leer.nextInt();
int S=Leer.nextInt();

System.out.println(2*S-R1);
            
    }
}