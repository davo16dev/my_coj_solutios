import java.util.Scanner;

/**
 *
 * @author David
 */
public class Main {

 
    public static void main(String[] args) {
      Scanner Leer =new Scanner(System.in);
      String a=Leer.nextLine();
     System.out.println("I got my first solution!!!");
    }
    
}