import java.util.Scanner;

/**
 *
 * @author Charlie-PC
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner Leer=new Scanner(System.in);
        
        
        
        
        
        
        
        while(true){    
            
           int y=Leer.nextInt();
           if(y==0){
           break;
           }
           ///////////////////////////////////////
          
           
           if(y==2)
                System.out.println(2);
           
           if(y==3)
                System.out.println(6);
           
           if(y==4)
                System.out.println(6);
           
           if(y==5)
                System.out.println(30);
           
           if(y==6)
                System.out.println(30);
           
           if(y==7)
                System.out.println(210);
           
           if(y==8)
                System.out.println(210);
           
           if(y==9)
                System.out.println(210);
           
           if(y==10)
                System.out.println(210);
            
           ///////////////////////////////////////
           if(y==11)
                System.out.println(2310);
           
           if(y==12)
                System.out.println(2310);
           
           if(y==13)
                System.out.println(30030);
           
           if(y==14)
                System.out.println(30030);
           
           if(y==15)
                System.out.println(30030);
           
           if(y==16)
                System.out.println(30030);
           
           if(y==17)
                System.out.println(510510);
           
           if(y==18)
                System.out.println(510510);
           
           if(y==19)
                System.out.println(9699690);
           
           if(y==20)
                System.out.println(9699690);
            
           ///////////////////////////////////////
           if(y==21)
                System.out.println(9699690);
           
           if(y==22)
                System.out.println(9699690);
           
           if(y==23)
                System.out.println(223092870);
           
           if(y==24)
                System.out.println(223092870);
           
           if(y==25)
                System.out.println(223092870);
           
           if(y==26)
                System.out.println(223092870);
           
           if(y==27)
                System.out.println(223092870);
           
           if(y==28)
                System.out.println(223092870);
           
           if(y==29)
                System.out.println("6469693230");
           
           if(y==30)
                System.out.println("6469693230");
           ///////////////////////////////////////
           if(y==31)
                System.out.println("200560490130");
           
           if(y==32)
                System.out.println("200560490130");
           
           if(y==33)
                System.out.println("200560490130");
           
           if(y==34)
                System.out.println("200560490130");
           
           if(y==35)
                System.out.println("200560490130");
           
           if(y==36)
                System.out.println("200560490130");
           
           if(y==37)
                System.out.println("7420738134810");
           
           if(y==38)
                System.out.println("7420738134810");
           
           if(y==39)
                System.out.println("7420738134810");
           
           if(y==40)
                System.out.println("7420738134810");
                    ///////////////////////////////////////
           if(y==41)
                System.out.println("304250263527210");
           
           if(y==42)
                System.out.println("304250263527210");
           
           if(y==43)
                System.out.println("13082761331670030");
           
           if(y==44)
                System.out.println("13082761331670030");
           
           if(y==45)
                System.out.println("13082761331670030");
           
           if(y==46)
                System.out.println("13082761331670030");
           
           if(y==47)
                System.out.println("614889782588491410");
           
           if(y==48)
                System.out.println("614889782588491410");
           
           if(y==49)
                System.out.println("614889782588491410");
           
           if(y==50)
                System.out.println("614889782588491410");
           
             
        }
                
        
        
    
    
    }
    
}
    