import java.util.Scanner;


public class Main {

 
    public static void main(String[] args) {
      Scanner Leer =new Scanner(System.in); 
int a=0;
      while(a!=42){
       a=Leer.nextInt();
     if(a!=42)
       System.out.println(a);
      }
      
    }}