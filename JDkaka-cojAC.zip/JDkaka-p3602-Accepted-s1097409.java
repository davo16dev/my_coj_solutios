import java.util.Scanner;

/**
 *
 * @author Davo1000
 */
public class COJdenuevo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        Scanner Leer=new Scanner(System.in);
        
        int x=Leer.nextInt();
        
        if(x==0)
            System.out.println("4");
    
        if(x==1)
            System.out.println("3");
    
        if(x==2)
            System.out.println("3");
    
        if(x==3)
            System.out.println("5");
        if(x==4)
            System.out.println("4");
        if(x==5)
            System.out.println("4");
       if(x==6)
            System.out.println("3");
       if(x==7)
            System.out.println("5");
       if(x==8)
            System.out.println("5");
    
       if(x==9)
            System.out.println("4");
    
       if(x==10)
            System.out.println("3");
    
    if(x==11)
            System.out.println("6");
    
    if(x==12)
            System.out.println("6");
    
    
    
    
    }
    
}