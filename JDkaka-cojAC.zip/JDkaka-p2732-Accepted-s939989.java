import java.util.Scanner;

/**
 *
 * @author Charlie-PC
 */
public class MayMin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    
        Scanner Leer=new Scanner(System.in);
        
        
        
        int x=Leer.nextInt();
        
        
        for (int i = 0; i < x; i++) {
            
            String pal=Leer.next();
            String pal1="";
            for (int j = 0; j < pal.length(); j++) {
                
                if(pal.charAt(j)=='a'){
                pal1=pal1+"A";
                }
                 if(pal.charAt(j)=='A'){
                pal1=pal1+"a";
                }
                
                //letras
                if(pal.charAt(j)=='b'){
                pal1=pal1+"B";
                }
                 if(pal.charAt(j)=='B'){
                pal1=pal1+"b";
                }
                
                 if(pal.charAt(j)=='c'){
                pal1=pal1+"C";
                }
                 if(pal.charAt(j)=='C'){
                pal1=pal1+"c";
                }
                 
                 
                if(pal.charAt(j)=='d'){
                pal1=pal1+"D";
                }
                 if(pal.charAt(j)=='D'){
                pal1=pal1+"d";
                }
                
                //letras
                if(pal.charAt(j)=='e'){
                pal1=pal1+"E";
                }
                 if(pal.charAt(j)=='E'){
                pal1=pal1+"e";
                }
                
                 if(pal.charAt(j)=='f'){
                pal1=pal1+"F";
                }
                 if(pal.charAt(j)=='F'){
                pal1=pal1+"f";
                }
                 
                 
                 
                 if(pal.charAt(j)=='g'){
                pal1=pal1+"G";
                }
                 if(pal.charAt(j)=='G'){
                pal1=pal1+"g";
                }
                
                //letras
                if(pal.charAt(j)=='h'){
                pal1=pal1+"H";
                }
                 if(pal.charAt(j)=='H'){
                pal1=pal1+"h";
                }
                
                 if(pal.charAt(j)=='i'){
                pal1=pal1+"I";
                }
                 if(pal.charAt(j)=='I'){
                pal1=pal1+"i";
                }
                 
                 
                if(pal.charAt(j)=='j'){
                pal1=pal1+"J";
                }
                 if(pal.charAt(j)=='J'){
                pal1=pal1+"j";
                }
                
                //letras
                if(pal.charAt(j)=='k'){
                pal1=pal1+"K";
                }
                 if(pal.charAt(j)=='K'){
                pal1=pal1+"k";
                }
                
                 if(pal.charAt(j)=='L'){
                pal1=pal1+"l";
                }
                 if(pal.charAt(j)=='l'){
                pal1=pal1+"L";
                }
                 
            
            
            
             if(pal.charAt(j)=='M'){
                pal1=pal1+"m";
                }
                 if(pal.charAt(j)=='m'){
                pal1=pal1+"M";
                }
                
                //letras
                if(pal.charAt(j)=='N'){
                pal1=pal1+"n";
                
                }
                
                
                    if(pal.charAt(j)=='n'){
                pal1=pal1+"N";}
                 if(pal.charAt(j)=='O'){
                pal1=pal1+"o";
                }
                
                 if(pal.charAt(j)=='o'){
                pal1=pal1+"O";
                }
                 if(pal.charAt(j)=='P'){
                pal1=pal1+"p";
                }
                 
                 
                if(pal.charAt(j)=='p'){
                pal1=pal1+"P";
                }
                 if(pal.charAt(j)=='Q'){
                pal1=pal1+"q";
                }
                
                //letras
                if(pal.charAt(j)=='q'){
                pal1=pal1+"Q";
                }
                 if(pal.charAt(j)=='r'){
                pal1=pal1+"R";
                }
                
                 if(pal.charAt(j)=='R'){
                pal1=pal1+"r";
                }
                 if(pal.charAt(j)=='S'){
                pal1=pal1+"s";
                }
                 
                 
                 
                 
                 if(pal.charAt(j)=='s'){
                pal1=pal1+"S";
                }
                
                 if(pal.charAt(j)=='t'){
                pal1=pal1+"T";
                }
                 if(pal.charAt(j)=='T'){
                pal1=pal1+"t";
                }
                 
                 
                if(pal.charAt(j)=='u'){
                pal1=pal1+"U";
                }
                 if(pal.charAt(j)=='U'){
                pal1=pal1+"u";
                }
                
                //letras
                if(pal.charAt(j)=='v'){
                pal1=pal1+"V";
                }
                 if(pal.charAt(j)=='V'){
                pal1=pal1+"v";
                }
                
                 if(pal.charAt(j)=='W'){
                pal1=pal1+"w";
                }
                 if(pal.charAt(j)=='w'){
                pal1=pal1+"W";
                }
                 
                 
                 if(pal.charAt(j)=='X'){
                pal1=pal1+"x";
                }
                 if(pal.charAt(j)=='x'){
                pal1=pal1+"X";
                }
                
                //letras
                if(pal.charAt(j)=='Y'){
                pal1=pal1+"y";
                }
                 if(pal.charAt(j)=='y'){
                pal1=pal1+"Y";
                }
                
                 if(pal.charAt(j)=='z'){
                pal1=pal1+"Z";
                }
                 if(pal.charAt(j)=='Z'){
                pal1=pal1+"z";
                }
                 
                 
            
            
            
            
            }
            
          System.out.println(pal1);
            
        }
    
    
    
    
    
    
}}