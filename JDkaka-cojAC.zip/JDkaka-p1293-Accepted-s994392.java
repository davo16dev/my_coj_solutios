import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author Davo1000
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner Leer = new Scanner(System.in);

        int x = Leer.nextInt();

        String pot = "";

        pot.indexOf(x);

        BigInteger bb = new BigInteger("2");

        System.out.println(bb.pow(x));

    }

}
