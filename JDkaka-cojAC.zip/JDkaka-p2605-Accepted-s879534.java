import java.util.Scanner;
public class DETERMINE {

    
    public static void main(String[] args) {
        Scanner Leer=new Scanner(System.in);
        int a=Leer.nextInt();
        if(a==1)
            System.out.println("1");
        if(a==2)
              System.out.println("7");
        if(a==3)
              System.out.println("2");
        if(a==4)
              System.out.println("3");
        
    }
    
}
