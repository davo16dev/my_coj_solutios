import java.util.Scanner;

/**
 *
 * @author David
 */
public class Main {

 
    public static void main(String[] args) {
      Scanner Leer =new Scanner(System.in);
      int a=Leer.nextInt();
      int b=Leer.nextInt();
      System.out.println(a+b);
    }
    
}