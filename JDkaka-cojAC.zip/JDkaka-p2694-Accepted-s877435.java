public class Main {

    public static void main(String[] args) {
       
        System.out.println("This is my first solution in programming competitions");
    }}